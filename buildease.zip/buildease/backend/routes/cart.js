const express = require("express");
const db = require("../db");
const router = express.Router();

// Get all cart items
router.get("/", (req, res) => {
  const query = "SELECT * FROM cart";
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Add item to cart
router.post("/", (req, res) => {
  const { product_id, quantity } = req.body;
  const query = "INSERT INTO cart (product_id, quantity) VALUES (?, ?)";
  db.query(query, [product_id, quantity], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Item added to cart", cartId: result.insertId });
  });
});

// Remove item from cart
router.delete("/:id", (req, res) => {
  const query = "DELETE FROM cart WHERE id = ?";
  db.query(query, [req.params.id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Item removed from cart" });
  });
});

module.exports = router;
