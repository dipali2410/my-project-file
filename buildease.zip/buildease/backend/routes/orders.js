const express = require("express");
const db = require("../db");
const router = express.Router();

// Place an order
router.post("/", (req, res) => {
  const { user_id, total_amount, payment_method } = req.body;
  const query =
    "INSERT INTO orders (user_id, total_amount, payment_method) VALUES (?, ?, ?)";
  db.query(query, [user_id, total_amount, payment_method], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Order placed successfully", orderId: result.insertId });
  });
});

// Get all orders
router.get("/", (req, res) => {
  const query = "SELECT * FROM orders";
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

module.exports = router;
