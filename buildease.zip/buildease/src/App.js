import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, Navigate, NavLink } from "react-router-dom";
import Home from "./components/Home";
import HomePage from "./components/HomePage";
import About from "./components/About";
import RegistrationForm from "./components/RegistrationForm";
import LoginForm from "./components/LoginForm";
import Dashboard from "./components/Dashboard";
import Products from "./components/Products";
import Cart from "./components/Cart";
import Payment from "./components/Payment";
import Tracking from "./components/Tracking"; // ✅ Ensure this is correctly imported

import "./styles/App.css";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem("isLoggedIn") === "true";
  });

  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");
    return savedCart ? JSON.parse(savedCart) : [];
  });

  // Persist cart in localStorage
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const handleLogin = () => {
    setIsLoggedIn(true);
    localStorage.setItem("isLoggedIn", "true");
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem("isLoggedIn");
    setCart([]); // Clear cart on logout
    localStorage.removeItem("cart");
  };

  return (
    <Router>
      <div className="App">
        <header className="header">
          <h1>BUILDEASE</h1>
          <nav className="nav">
            <NavLink to="/" exact>Home</NavLink>
            <NavLink to="/about">About</NavLink>
            {!isLoggedIn ? (
              <>
                <NavLink to="/login">Login</NavLink>
                <NavLink to="/register">Register</NavLink>
              </>
            ) : (
              <>
                <NavLink to="/home">Dashboard</NavLink>
                <NavLink to="/products">Products</NavLink>
                <NavLink to="/cart">Cart{cart.length > 0 ? ` (${cart.length})` : ""}</NavLink>
                <NavLink to="/payment">Payment</NavLink>
                <NavLink to="/tracking">Tracking</NavLink>
                <button onClick={handleLogout} className="logout-button">Logout</button>
              </>
            )}
          </nav>
        </header>

        <main className="main-content">
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/login" element={<LoginForm onLogin={handleLogin} />} />
            <Route path="/register" element={<RegistrationForm />} />

            {/* Protected Routes */}
            <Route path="/home" element={isLoggedIn ? <HomePage /> : <Navigate to="/login" replace />} />
            <Route path="/dashboard" element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" replace />} />
            <Route path="/products" element={isLoggedIn ? <Products cart={cart} setCart={setCart} /> : <Navigate to="/login" replace />} />
            <Route path="/cart" element={isLoggedIn ? <Cart cart={cart} setCart={setCart} /> : <Navigate to="/login" replace />} />
            <Route path="/payment" element={isLoggedIn ? <Payment cart={cart} /> : <Navigate to="/login" replace />} />
            <Route path="/tracking" element={isLoggedIn ? <Tracking navigateToHome={() => <Navigate to="/home" replace />} /> : <Navigate to="/login" replace />} />
          </Routes>
        </main>

        <footer className="footer">
          <div>
            <h3>BUILDEASE</h3>
            <p>This project addresses inefficiencies in construction material logistics.</p>
          </div>
          <div>
            <h4>Contact Us</h4>
            <p>Email: CONNECT@BUILDEASE.com</p>
            <p>Phone: 9860671310</p>
          </div>
          <div>
            <h4>Follow Us</h4>
            <p>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a> |{" "}
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a> |{" "}
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a> |{" "}
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">LinkedIn</a>
            </p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
