import React from "react";

const Dashboard = () => {
  return (
    <div className="dashboard">
      <h2>Welcome to the Dashboard</h2>
      <p>This is the user dashboard where key information is displayed.</p>
    </div>
  );
};

export default Dashboard;
