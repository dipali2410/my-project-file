import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import for navigation
import "./../styles/Forms.css";

const LoginForm = ({ onLogin }) => { // Accept onLogin prop
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false); // State to track modal
  const navigate = useNavigate(); // Hook for navigation

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Login Data:", { email, password });

    // Simulate login success
    setIsLoggedIn(true);
    onLogin(); // Call the onLogin function from App.js

    // Navigate to the products page after login
    setTimeout(() => {
      navigate("/products");
    }, 2000);
  };

  const closeModal = () => {
    setIsLoggedIn(false);
  };

  return (
    <div>
      <form className="form-container" onSubmit={handleSubmit}>
        <h2>Login</h2>
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Login</button>
      </form>

      {/* Modal for success */}
      {isLoggedIn && (
        <div className="modal">
          <div className="modal-content">
            <h3>Login Successful!</h3>
            <p>Redirecting to your products page...</p>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginForm;