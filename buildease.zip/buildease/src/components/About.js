import React from "react";
import "./../styles/About.css";
const About = () => {
  return (
    <div className="about">
      <h2>About BuildEase</h2>
      <p>
      At BuildEase, our mission is to revolutionize construction material management by providing a seamless, efficient, and technology-drive
       platform for suppliers, contractors, and transporters. Our goal is to streamline the supply chain, reduce delays, and enhance communication 
       between all stakeholders in the construction industry.

      </p>
    </div>
  );
};

export default About;
