import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { addToCart, removeFromCart } from "../redux/cartSlice";

const Products = () => {
  const dispatch = useDispatch();
  const cart = useSelector((state) => state.cart.cartItems); // Use cartItems array

  const products = [
    { id: 1, name: "Cement( per bag)", price: 500 },
    { id: 2, name: "Bricks (per 100 piece)", price: 1000 },
    { id: 3, name: "Steel Rods(per piece)", price: 2000 },
    { id: 4, name: "Sand (per 1 brass)", price: 4000 },
    { id: 5, name: "Crossaint (per 1 brass)", price: 4000 },
    { id: 6, name: "Iron (per ton)", price: 55000 },
  ];

  return (
    <div className="products-container">
      <h2>Products</h2>
      <div className="products-grid">
        {products.map((product) => (
          <div key={product.id} className="product-card">
            <h3>{product.name}</h3>
            <p>Price: ₹{product.price}</p>
            <button onClick={() => dispatch(addToCart(product))}>Add to Cart</button>
            {cart.some((item) => item.id === product.id) && (
              <button onClick={() => dispatch(removeFromCart(product.id))}>Remove</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Products;
