import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { removeFromCart, updateQuantity } from "../redux/cartSlice";
import "./../styles/cart.css";

const Cart = () => {
  const cart = useSelector((state) => state.cart.cartItems);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  if (!Array.isArray(cart)) {
    console.error("Cart is not an array:", cart);
    return <p>Error: Cart data is invalid</p>;
  }

  // Calculate total price
  const totalPrice = cart.reduce((total, item) => total + item.price * item.quantity, 0);

  return (
    <div className="cart-container">
      <h2>🛒 Shopping Cart</h2>

      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <ul>
            {cart.map((item) => (
              <li key={item.id} className="cart-item">
                <span>{item.name} - ₹{item.price * item.quantity}</span>
                <div className="quantity-controls">
                  <button 
                    onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }))}
                    disabled={item.quantity <= 1}
                  >
                    ➖
                  </button>
                  <span>{item.quantity}</span>
                  <button 
                    onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}
                  >
                    ➕
                  </button>
                </div>
                <button className="remove-btn" onClick={() => dispatch(removeFromCart(item.id))}>
                  ❌ Remove
                </button>
              </li>
            ))}
          </ul>

          {/* Total Price */}
          <div className="cart-summary">
            <h3>Total: ₹{totalPrice}</h3>
          </div>

          {/* Payment Button - Positioned Above Footer */}
          <div className="payment-button-container">
            <button className="payment-button" onClick={() => navigate("/payment")}>
              💳 Proceed to Payment
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
