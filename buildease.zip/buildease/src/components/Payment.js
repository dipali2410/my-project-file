import React, { useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom"; // Import useNavigate for redirection
import "../styles/payment.css";

const PaymentPage = () => {
  const navigate = useNavigate(); // Initialize navigation hook
  const rawCartItems = useSelector((state) => state.cart.cartItems);
  
  // Memoizing cart items to optimize performance
  const cartItems = useMemo(() => rawCartItems || [], [rawCartItems]);

  const [selectedMethod, setSelectedMethod] = useState("");
  const [address, setAddress] = useState("");
  const [bankDetails, setBankDetails] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    upiId: "",
  });
  const [errors, setErrors] = useState({});
  const [totalAmount, setTotalAmount] = useState(0);
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    setTotalAmount(cartItems.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0));
  }, [cartItems]);

  const validateForm = () => {
    let newErrors = {};

    // Address validation: At least 10 characters, must contain letters and numbers
    if (!address.trim()) {
      newErrors.address = "⚠ Address is required!";
    } else if (address.length < 10) {
      newErrors.address = "⚠ Address must be at least 10 characters long!";
    } else if (!/[A-Za-z]/.test(address) || !/\d/.test(address)) {
      newErrors.address = "⚠ Address must include both letters and numbers!";
    }

    // ✅ Payment method validation added
    if (!selectedMethod) {
      newErrors.selectedMethod = "⚠ Please select a payment method!";
    }

    if (selectedMethod === "Net Banking") {
      // ✅ Card Number Validation
      if (!/^\d{16}$/.test(bankDetails.cardNumber)) {
        newErrors.cardNumber = "⚠ Card number must be exactly 16 digits!";
      }

      // ✅ Expiry Date Validation
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(bankDetails.expiryDate)) {
        newErrors.expiryDate = "⚠ Format should be MM/YY!";
      } else {
        const [month, year] = bankDetails.expiryDate.split("/").map(Number);
        const currentYear = new Date().getFullYear() % 100; // Get last two digits of the year
        const currentMonth = new Date().getMonth() + 1;

        if (year < currentYear || (year === currentYear && month < currentMonth)) {
          newErrors.expiryDate = "⚠ Expiry date must be in the future!";
        }
      }

      // ✅ CVV Validation
      if (!/^\d{3}$/.test(bankDetails.cvv)) {
        newErrors.cvv = "⚠ CVV must be 3 digits!";
      }
    }

    if (selectedMethod === "UPI" && !/^[a-zA-Z0-9.\-_]+@[a-zA-Z]+$/.test(bankDetails.upiId)) {
      newErrors.upiId = "⚠ Enter a valid UPI ID (e.g., example@upi)!";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePayment = () => {
    if (!validateForm()) return;

    setShowPopup(true);
  };

  const handleRedirect = () => {
    // Reset form fields
    setAddress("");
    setSelectedMethod("");
    setBankDetails({ cardNumber: "", expiryDate: "", cvv: "", upiId: "" });
    setTotalAmount(0);
    setShowPopup(false);

    navigate("/"); // Redirect to Homepage
  };

  return (
    <div className="payment-container">
      <h2>🛒 Checkout</h2>
      <div className="amount-box">
        <p>Total Amount:</p>
        <span className="amount">₹{totalAmount}</span>
      </div>
      
      {totalAmount <= 0 && <p className="error">⚠ Payment is not valid for ₹0. Please add items to your cart.</p>}
      
      <input
        type="text"
        placeholder="Enter Delivery Address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
        className="input-box"
        required
      />
      {errors.address && <p className="error">{errors.address}</p>}

      <div className="payment-methods">
        <h3>Select Payment Method</h3>
        {["Net Banking", "UPI", "Cash on Delivery"].map((method) => (
          <button
            key={method}
            className={selectedMethod === method ? "selected" : ""}
            onClick={() => {
              setSelectedMethod(method);
              setErrors({ ...errors, selectedMethod: "" }); // Clear error when a method is selected
            }}
          >
            {method}
          </button>
        ))}
        {errors.selectedMethod && <p className="error">{errors.selectedMethod}</p>}
      </div>

      {(selectedMethod === "Net Banking" || selectedMethod === "UPI") && (
        <div className="payment-form">
          {selectedMethod === "Net Banking" && (
            <>
              <input type="text" placeholder="Card Number (16 digits)" value={bankDetails.cardNumber}
                onChange={(e) => setBankDetails({ ...bankDetails, cardNumber: e.target.value })}
                className="input-box" required />
              {errors.cardNumber && <p className="error">{errors.cardNumber}</p>}

              <input type="text" placeholder="Expiry Date (MM/YY)" value={bankDetails.expiryDate}
                onChange={(e) => setBankDetails({ ...bankDetails, expiryDate: e.target.value })}
                className="input-box" required />
              {errors.expiryDate && <p className="error">{errors.expiryDate}</p>}

              <input type="password" placeholder="CVV (3 digits)" value={bankDetails.cvv}
                onChange={(e) => setBankDetails({ ...bankDetails, cvv: e.target.value })}
                className="input-box" required />
              {errors.cvv && <p className="error">{errors.cvv}</p>}
            </>
          )}
          {selectedMethod === "UPI" && (
            <>
              <input type="text" placeholder="UPI ID (e.g., example@upi)" value={bankDetails.upiId}
                onChange={(e) => setBankDetails({ ...bankDetails, upiId: e.target.value })}
                className="input-box" required />
              {errors.upiId && <p className="error">{errors.upiId}</p>}
            </>
          )}
        </div>
      )}

      <button 
        className="pay-button" 
        onClick={handlePayment} 
        disabled={totalAmount <= 0}
      >
        Pay ₹{totalAmount}
      </button>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <h3>🎉 Order Placed Successfully!</h3>
            <p>Your payment of ₹{totalAmount} was successful.</p>
            <p>Thank you for shopping with us!</p>
            <button onClick={handleRedirect}>OK</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentPage;
