import React, { useState } from "react";
import "./../styles/Forms.css";

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    mobile: "",
    email: "",
    businessType: "",
    password: "",
    confirmPassword: "",
  });

  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false); // State to track submission

  const validateForm = () => {
    let newErrors = {};

    // Full Name Validation (Only letters & spaces, min 3 characters)
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full Name is required!";
    } else if (!/^[A-Za-z\s]+$/.test(formData.fullName)) {
      newErrors.fullName = "Full Name must contain only letters and spaces!";
    } else if (formData.fullName.length < 3) {
      newErrors.fullName = "Full Name must be at least 3 characters long!";
    }

    // Password Match Validation
    if (formData.password !== formData.confirmPassword) {
      newErrors.password = "Passwords do not match!";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" }); // Clear error on change
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return; // Prevent form submission if validation fails
    setIsSubmitted(true);
    console.log("Registration Data:", formData);
  };

  const closeModal = () => {
    setIsSubmitted(false);
  };

  return (
    <div>
      <form className="form-container" onSubmit={handleSubmit}>
        <h2>Register</h2>

        {/* Full Name Input */}
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={formData.fullName}
          onChange={handleChange}
          required
        />
        {errors.fullName && <p className="error">{errors.fullName}</p>}

        {/* Mobile Input */}
        <input
          type="tel"
          name="mobile"
          placeholder="Mobile Number"
          value={formData.mobile}
          onChange={handleChange}
          required
        />

        {/* Email Input */}
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          required
        />

        {/* Business Type Selection */}
        <select name="businessType" value={formData.businessType} onChange={handleChange} required>
          <option value="">Select Business Type</option>
          <option value="Supplier">Supplier</option>
          <option value="Customer">Customer</option>
        </select>

        {/* Password Input */}
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          required
        />

        {/* Confirm Password Input */}
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          onChange={handleChange}
          required
        />
        {errors.password && <p className="error">{errors.password}</p>}

        {/* Register Button */}
        <button type="submit">Register</button>
      </form>

      {/* Success Modal */}
      {isSubmitted && (
        <div className="modal">
          <div className="modal-content">
            <h3>✅ Registration Successful!</h3>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RegistrationForm;
