import React from "react";
import "./../styles/Home.css";

const Home = () => {
  return (
    <div className="home">
      <h2>BUILDEASE</h2>
      <div className="features">
        <div className="feature-card">
          <h3>TRACK VEHICLES</h3>
          <p>Save time with live GPS </p>
        </div>
        <div className="feature-card">
          <h3>MAKE EFECTIVE BUSSINESS</h3>
          <p>Connect with your materials.</p>
        </div>
        <div className="feature-card">
          <h3>TRACK PROGRESS</h3>
          <p>Monitor your Daily orders.</p>
        </div>
      </div>
    </div>
  );
};

export default Home;
