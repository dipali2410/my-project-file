import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav style={{ display: 'flex', justifyContent: 'space-around', padding: '10px', background: '#007bff', color: 'white' }}>
      <NavLink to="/products" style={{ color: 'white', textDecoration: 'none' }}>Products</NavLink>
      <NavLink to="/cart" style={{ color: 'white', textDecoration: 'none' }}>Cart</NavLink>
      <NavLink to="/payment" style={{ color: 'white', textDecoration: 'none' }}>Payment</NavLink>
      <NavLink to="/tracking" style={{ color: 'white', textDecoration: 'none' }}>Tracking</NavLink>
    </nav>
  );
};

export default Navbar;
