import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles/Tracking.css";

const TrackingPage = ({ orderId }) => {
  const navigate = useNavigate();
  const [status, setStatus] = useState("Order Placed");
  const [loading, setLoading] = useState(true);
  const [showCancelPopup, setShowCancelPopup] = useState(false);
  const [cancelMessage, setCancelMessage] = useState("");

  const statusList = ["Order Placed", "Order Confirmed", "Order Processed", "Ready to Pickup", "Delivered"];

  // ✅ Fetch Order Status
  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/order-status/${orderId}`);
        setStatus(response.data.status);
      } catch (error) {
        console.error("Error fetching order status:", error);
      }
      setLoading(false);
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 2 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, [orderId]);

  // ✅ Handle Order Cancellation
  const handleSubmitCancellation = async () => {
    setShowCancelPopup(false); // Close popup
    setCancelMessage("⏳ Your cancelling order is in progress...");

    try {
      await axios.post(`http://localhost:5000/api/cancel-order`, { orderId });
      setStatus("Canceled");

      // ✅ Show "Order Cancelled" message after 5 seconds
      setTimeout(() => {
        setCancelMessage("✅ Order Cancelled");

        // ✅ Redirect after 2 more seconds
        setTimeout(() => {
          navigate("/home"); // 🔥 Redirects to HomePage
        }, 2000);
      }, 5000);
    } catch (error) {
      console.error("Error canceling order:", error);
      setCancelMessage("✅ Order Cancelled.");
    }
  };

  return (
    <div className="tracking-container">
      <h2>📦 Track Order</h2>
      <p><strong>Estimated Time:</strong> 30 minutes</p>
      <p><strong>Order Number:</strong> 10025{orderId}</p>

      {loading ? (
        <p className="loading">⏳ Fetching order status...</p>
      ) : (
        <div className="tracking-status">
          {statusList.map((step, index) => {
            const isActive = status === step;
            const isCompleted = statusList.indexOf(status) > index;
            return (
              <div key={step} className={`status-item ${isActive ? "active" : isCompleted ? "completed" : ""}`}>
                <div className="status-icon">{isCompleted ? "✔" : index + 1}</div>
                <div className="status-text">
                  <strong>{step}</strong>
                  {isActive && <p>🟡 In Progress...</p>}
                  {step === "Delivered" && status === "Delivered" && <p>🎉 Your order has been delivered!</p>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {status !== "Delivered" && status !== "Canceled" && (
        <button className="cancel-button" onClick={() => setShowCancelPopup(true)}>❌ Cancel Order</button>
      )}

      {showCancelPopup && (
        <div className="popup">
          <p>Are you sure you want to cancel your order?</p>
          <button onClick={() => setShowCancelPopup(false)}>❌ No</button>
          <button onClick={handleSubmitCancellation}>✅ Yes</button>
        </div>
      )}

      {cancelMessage && (
        <div className="popup">
          <p>{cancelMessage}</p>
        </div>
      )}
    </div>
  );
};

export default TrackingPage;
