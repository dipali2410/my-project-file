import React from "react";
import { useNavigate } from "react-router-dom";

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="home-page-container">
      <h2>Welcome to Buildease</h2>
      <p>Your one-stop solution for construction material logistics.</p>
      <div className="buttons-container">
        <button onClick={() => navigate("/products")} className="home-button">
          Products
        </button>
        <button onClick={() => navigate("/cart")} className="home-button">
          Cart
        </button>
        <button onClick={() => navigate("/payment")} className="home-button">
          Payment
        </button>
        <button onClick={() => navigate("/tracking")} className="home-button">
          Tracking
        </button>
      </div>
    </div>
  );
};

export default HomePage;
