import React from 'react';
import './styles.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div>
        <h3>BUILDEASE</h3>
        <p>BuildEase is a platform designed to connect suppliers, transporters, and contractors in the construction industry.</p>
      </div>
      <div>
        <h3>Contact Us</h3>
        <p>Email: support@buildease.com</p>
        <p>Phone: (555) 123-4567</p>
      </div>
      <div>
        <h3>Follow Us</h3>
        <p>Facebook | Twitter | Instagram | LinkedIn</p>
      </div>
    </footer>
  );
};

export default Footer;
